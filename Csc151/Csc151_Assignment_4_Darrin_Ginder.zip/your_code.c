#include "your_code.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Write the implementations of the functions that do the rea
ASTNode* CreateDeclarationListNode(ASTNode* dc, ASTNode* dcList)
{
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_DECLARATION_LIST;
	node->left = dc;
	node->right = dcList;
	return node;
}

void AddDeclaration(char* name)
{
	struct Name *names = (struct Name*) malloc(sizeof(struct Name));
	names = Search(name);
	if(names != NULL){
		char temp[(strlen("Multiple declarations of ") + strlen(name) + 2)];
		strcpy(temp, "Multiple declarations of ");
		strcat(temp, "'");
		strcat(temp, name);
		strcat(temp, "'");
		yyerror (temp); 
	}else{
		Insert(name);
	}
}

ASTNode* CreateStatementListNode(ASTNode* st, ASTNode* stList)
{

	
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_STATEMENT_LIST;
	node->left = st;
	node->right = stList;
	return node;
}

ASTNode* CreateAssignmentNode(ASTNode* ident, ASTNode* expr)
{
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_ASSIGN;

	node->left = ident;
	node->right = expr;
}

ASTNode* CreateAddNode(ASTNode* expr, ASTNode* term){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_ARITH_OP;
	node->op = ADD_OP;
	node->left = expr;
	node->right = term;
	return node;
}

ASTNode* CreateSubNode(ASTNode* expr, ASTNode* term){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_ARITH_OP;
	node->op = SUB_OP;
	node->left = expr;
	node->right = term;
	return node;
}

ASTNode* CreateMulNode(ASTNode* term, ASTNode* factor){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_ARITH_OP;
	node->op = MUL_OP;
	node->left = term;
	node->right = factor;
	return node;
}

ASTNode* CreateDivNode(ASTNode* term, ASTNode* factor){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_ARITH_OP;
	node->op = DIV_OP;
	node->left = term;
	node->right = factor;
	return node;
}

ASTNode* CreateIdentNode(char* name)
{

	struct Name *names = (struct Name*) malloc(sizeof(struct Name));
	names = Search(name);
	if(names == NULL){
		yyerror (name);
		printf("Ident not declared");
   		exit(1);
	}
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
        node->type = ASTNODE_IDENT; 
        node->name = name;
        return node;

}

ASTNode* CreateNumNode(int num)
{
        ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
        node->type = ASTNODE_NUM; 
        node->num = num;
        return node;
}

ASTNode* CreateIfNode(ASTNode* condList, ASTNode* statList){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_IF; 
	node->left = condList;
	node->right = statList;
	return node;
}

ASTNode* CreateIfElseNode(ASTNode* condList, ASTNode* statList, ASTNode* elseStatList){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_IF_ELSE; 
	node->left = CreateIfNode(condList, statList);
	node->right = elseStatList;
	return node;
}

ASTNode* CreateConditionListNode(ASTNode* cond, ASTNode* condList){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_LOGIC_OP; 
	node->op = OR_OP;
	node->left = cond;
	node->right = condList;
	return node;
}

ASTNode* CreateConditionNode(ASTNode* comp, ASTNode* cond){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_LOGIC_OP;
	node->op = AND_OP;
	node->left = comp;
	node->right = cond;
	return node;
}

ASTNode* CreateEqualNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = EQUAL_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateNotEqualNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = NOTEQUAL_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateGreaterNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = GREATER_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateLesserNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = LESSER_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateLesserEqualNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = LESSEREQUAL_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateGreaterEqualNode(ASTNode* exprLeft, ASTNode* exprRight){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_COMPARE_OP;
	node->op = GREATEREQUAL_OP;
	node->left = exprLeft;
	node->right = exprRight;
	return node;
}

ASTNode* CreateWhileNode(ASTNode* cond, ASTNode* statList){
	ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
	node->type = ASTNODE_WHILE;
	node->left = cond;
	node->right = statList;
	return node;
}


int hasher(char *name) {	
	int key = 0;
	int i;
	int value = strlen(name);

	for(i=0; i < value; i++){
		key += (name[i] - '0');
	}

	int index = key % SIZE;
	return index;
}


void Insert(char *name){
	struct Name *ident = (struct Name*) malloc(sizeof(struct Name));
	ident->name = name;
	int index = hasher(name);

  	while(hash[index] != NULL) {
      		++index;
      		index %= SIZE;
   	}
	
   	hash[index] = ident;
	
}

struct Name *Search(char* name) {
	int index = hasher(name);  
	
	while(hash[index] != NULL) {
	
		if(0==strcmp(hash[index]->name, name))
			return hash[index]; 
			
		++index;
		
		index %= SIZE;
	}        
	
	return NULL;        
}



// Commented out in this assignment 
/*void GenerateILOC(ASTNode* node);
{

}*/



